export default {
  domain: 'http://huynhsamha.github.io',
  shareEncryptKey: 'zH3Vzf'
};
