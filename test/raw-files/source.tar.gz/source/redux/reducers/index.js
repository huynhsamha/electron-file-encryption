import { combineReducers } from 'redux';

import Alert from './alert';

export default combineReducers({
  Alert
});
